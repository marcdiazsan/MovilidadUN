package com.example.map;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.maps.android.ui.IconGenerator;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

//actividad que muestra graficamente la ruta sin poder modificarla(para seleccionar la para los pasajeros)

public class mapSeenUsers extends AppCompatActivity implements OnMapReadyCallback {
    GoogleMap map;
    private static final String TAG = "MainActivity";

    private MarkerOptions origin, end;
    private Polyline currentPolyline;
    private ArrayList<LatLng> paraderos;
    private IconGenerator icgOrigin;
    private IconGenerator icgEnd;
    private IconGenerator paradero;
    private Ruta ruta;
    private List<LatLng> puntosPolyLine;
    private ArrayList<Ruta> rutasArchivo;

    //lo importate es tener el ID, eso es lo que se debe pasar entre actividades
    private String Id="7077";

    private FusedLocationProviderClient client;
    MapFragment mapFragment;
    private Usuario usuario;

    FileOutputStream file = null;
    FileInputStream inputFile = null;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map_seen_users);
        client = LocationServices.getFusedLocationProviderClient(this);

        if (ActivityCompat.checkSelfPermission(mapSeenUsers.this, Manifest.permission.ACCESS_FINE_LOCATION)== PackageManager.PERMISSION_GRANTED){
            getCurrentLocation();
        }
        else {
            ActivityCompat.requestPermissions(mapSeenUsers.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION},44);
        }

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        //map.setMyLocationEnabled(true);


        
        paraderos = new ArrayList<LatLng>();
        mapFragment = (MapFragment) getFragmentManager().findFragmentById(R.id.mapFrag);
        getCurrentLocation();

        //funcion que carga el archivo de las rutas

        cargarArchivo("Rutas.obj");

        //por default se escoge la primera, pero la idea seria que fuera la que se necesita

        mapFragment.getMapAsync(this);

    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        map = googleMap;
        icgOrigin= new IconGenerator(this);
        icgEnd = new IconGenerator(this);
        paradero = new IconGenerator(this);
        puntosPolyLine = new ArrayList<>();
        PolylineOptions line = new PolylineOptions();

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        map.setMyLocationEnabled(true);

        origin = new MarkerOptions();
        end = new MarkerOptions();

        //pone el origen en el mapa
        String oriString = "Origen: "+ getAddress(new LatLng(ruta.getLatOrigen(),ruta.getLngOrigen()));
        origin.position(new LatLng(ruta.getLatOrigen(),ruta.getLngOrigen()));
        icgOrigin.setStyle(IconGenerator.STYLE_GREEN);
        origin.title("Origen");
        Log.d("mylog", "Added Marker Origin");
        addIcon(map, icgOrigin, "Origen",new LatLng(ruta.getLatOrigen(),ruta.getLngOrigen()),oriString);

        //poner el destino en el mapa
        String desString = "Origen: "+ getAddress(new LatLng(ruta.getLatDestino(),ruta.getLngDestino()));
        end.position(new LatLng(ruta.getLatDestino(),ruta.getLngDestino()));
        icgEnd.setStyle(IconGenerator.STYLE_RED);
        end.title("Destino");
        Log.d("mylog", "Added Marker End");
        addIcon(map, icgEnd, "Destino",new LatLng(ruta.getLatDestino(),ruta.getLngDestino()),desString);

        //pone los paraderos en el mapa
        for(int i=0; i<ruta.getLatParaderos().size();i++){
            String desPar = "Paradero: "+ getAddress(new LatLng(ruta.getLatParaderos().get(i),ruta.getLngParaderos().get(i)));
            icgEnd.setStyle(IconGenerator.STYLE_ORANGE);
            paraderos.add(new LatLng(ruta.getLatParaderos().get(i),ruta.getLngParaderos().get(i)));
            Log.d("mylog", "Added Paradero");
            addIcon(map,paradero,"Paradero",new LatLng(ruta.getLatParaderos().get(i),ruta.getLngParaderos().get(i)),desPar);
        }

        for (int j=0; j<ruta.getLatLineaRuta().size();j++){
            puntosPolyLine.add(new LatLng(ruta.getLatLineaRuta().get(j),ruta.getLngLineaRuta().get(j)));
        }
        //adiciona la polyline de la ruta
        line.addAll(puntosPolyLine);
        line.width(10);
        line.color(Color.BLUE);
        currentPolyline=map.addPolyline(line);

    }

    //carga el archivo de las rutas
    private void cargarArchivo(String nombreArchivo){

        DatabaseReference ref = (DatabaseReference) FirebaseDatabase.getInstance().getReference("Rutas").orderByChild("id").equalTo(Id);
        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    Ruta rutaTmp;
                    List<Double> latParaderos;
                    List<Double> lngParaderos;
                    List<Double> latLineaRuta;
                    List<Double> lngLineaRuta;
                    List<String> pasajeros;
                    HashMap output = (HashMap) snapshot.getValue();
                    HashMap output2 = (HashMap) output.get(Id);
                    System.out.println(output2);
                    String id = (String) output2.get("id");
                    String usuario = (String) output2.get("usuario");
                    String fecha = (String) output2.get("fecha");
                    String hora = (String) output2.get("hora");
                    double latOrigin = (double) Double.valueOf(output2.get("latOrigen").toString());
                    double lngOrigin = (double) Double.valueOf(output2.get("lngOrigen").toString());
                    double latDestino = (double) Double.valueOf(output2.get("latDestino").toString());
                    double lngDestino = (double) Double.valueOf(output2.get("lngDestino").toString());
                    try {
                        latParaderos = (List<Double>) makeSplit(output.get("latParaderos").toString());
                        lngParaderos = (List<Double>) makeSplit(output.get("lngParaderos").toString());
                    } catch (NullPointerException e) {
                        latParaderos = new ArrayList<>();
                        lngParaderos = new ArrayList<>();
                    }
                    String placa = (String) output2.get("placa");

                    try {
                        latLineaRuta = (List<Double>) makeSplit(output.get("latLineaRuta").toString());
                        lngLineaRuta = (List<Double>) makeSplit(output2.get("lngLineaRuta").toString());

                    } catch (NullPointerException e) {
                        latLineaRuta = new ArrayList<>();
                        lngLineaRuta = new ArrayList<>();
                    }

                    try {
                        pasajeros = (List<String>) makeSplit2(output2.get("pasajeros").toString());
                    } catch (NullPointerException e) {
                        pasajeros = new ArrayList<>();
                    }

                    rutaTmp = new Ruta(id, usuario, fecha, hora, latOrigin, lngOrigin, latDestino, lngDestino, latParaderos, lngParaderos, placa, latLineaRuta, lngLineaRuta, pasajeros);
                    ruta = rutaTmp;
                } else {
                    System.out.println("error");
                }
            }


                @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Ruta rutaTmp=new Ruta(null,null);
                ruta=rutaTmp;
                Toast.makeText(mapSeenUsers.this,"Id no valido",Toast.LENGTH_SHORT);

            }
        });


    }

        private List<String> makeSplit2(String stringArray){
            String sub = stringArray.substring(1,stringArray.length()-1);
            String[] parts= sub.split(",");
            List<String> ret = new ArrayList<>();
            for (int i =0; i<parts.length;i++){
                ret.add(parts[i]);
            }
            return ret;

        }

        private List<Double> makeSplit(String stringArray){
            String sub = stringArray.substring(1,stringArray.length()-1);
            String[] parts= sub.split(",");
            List<Double> ret = new ArrayList<>();
            for (int i =0; i<parts.length;i++){
                ret.add(Double.valueOf(parts[i]));
            }
            return ret;

        }


        //obtiene la direccion de las paraderos, origen y fin
    private String getAddress(LatLng place){
        Geocoder geocoder;
        List<Address> addresses;
        String address = null;
        geocoder = new Geocoder(this, Locale.getDefault());
            try {
                addresses = geocoder.getFromLocation(place.latitude, place.longitude, 1);
                address = addresses.get(0).getAddressLine(0);
            } catch (Exception e) {
                e.printStackTrace();
        }
        return address;
    }

    //obtiene la ubicacion actual
    private void getCurrentLocation(){
        @SuppressLint("MissingPermission") Task<Location> task = client.getLastLocation();
        task.addOnSuccessListener(new OnSuccessListener<Location>() {
            @Override
            public void onSuccess(Location location) {
                if (location != null){
                    mapFragment.getMapAsync(new OnMapReadyCallback() {
                        @Override
                        public void onMapReady(GoogleMap googleMap) {
                            LatLng latLng = new LatLng(location.getLatitude(),location.getLongitude());
                            MarkerOptions options = new MarkerOptions().position(latLng).title("Posicion Actual");
                            googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng,16));
                            googleMap.addMarker(options);
                        }
                    });
                }
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if(requestCode == 44){
            if(grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
                getCurrentLocation();
            }
        }
    }

    private void addIcon(GoogleMap googleMap, IconGenerator iconFactory, CharSequence text, LatLng position,String title) {
        MarkerOptions markerOptions = new MarkerOptions().
                icon(BitmapDescriptorFactory.fromBitmap(iconFactory.makeIcon(text))).
                position(position).
                anchor(iconFactory.getAnchorU(), iconFactory.getAnchorV()).title(title);
        googleMap.addMarker(markerOptions);
    }


}