package com.example.map;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.model.LatLng;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

//actividad para revisar la ruta y seleccionar los paraderos a los que se quiere agregar el pasajero

public class checkRuta extends AppCompatActivity {
    private ArrayList<Ruta> rutasArchivo;
    private Ruta ruta;

    //lo realmente importante para tener la ruta es el ID, asi que eso es lo que se debe pasar entre actividades, al seleccionar cosas
    private String Id="1410";
    private Usuario conductor;

    ListView listParaderos;
    ListView listPasajeros;
    List listaPasajeros;
    List listaParaderos;
    List lPasajeros;
    Button verRuta;
    Button validar;
    ImageButton perfilConductor;
    FileOutputStream file = null;

    //pasajero en particular, solo usuarios que no sean el conductor, pueden escoger y agregarse a paraderos
    Usuario persona = new Usuario("Jane","Doe","+573048759028","jdoe@example.com");


    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_check_ruta);

        verRuta = findViewById(R.id.verRuta);
        validar = findViewById(R.id.Validar);
        perfilConductor = findViewById(R.id.verPerfilConductor);
        //cargar el archivo de rutas y escoge la ruta 0 por default

        cargarArchivo();

        //imprime el titulo de la ruta
        TextView tituloRuta = (TextView) findViewById(R.id.nombreRuta);
        String tRuta="Ruta "+ruta.getId();
        tituloRuta.setText(tRuta);

        //imprime el nombre del conductor
        TextView nombreConductor = (TextView) findViewById(R.id.nombreConductor);
        getConductor(ruta.getUsuario());
        String tConductor = conductor.getNombre()+ " "+ conductor.getApellido();
        nombreConductor.setText(tConductor);

        //imprime placa
        TextView placa = (TextView) findViewById(R.id.placaModelo);
        placa.setText(ruta.getPlaca());
        //imprime hora y fecha de la ruta
        TextView horaFecha =(TextView) findViewById(R.id.fechaHora);
        horaFecha.setText(ruta.getFecha()+" "+ ruta.getHora());

        perfilConductor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //cambiar a ver el perfil del conductor
            }
        });

        //listener del boton para cambiar la actividad (a mapSeenUsers)
        verRuta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                changeAct();
            }
        });

        //listener para validad que ahora se adiciono un pasajero y volver al menu de las rutas
        validar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                guardarRuta(ruta);
                //cambiar a la inicial
            }
        });

        listParaderos = (ListView) findViewById(R.id.listaParaderos);
        listPasajeros = (ListView) findViewById(R.id.listaPasajeros);



        listaParaderos = new ArrayList<String>();
        listaPasajeros = new ArrayList<Usuario>();
        lPasajeros = new ArrayList<String>();
        //getParaderos(ruta,persona);
        //getPasajeros();


    }
    public void changeAct() {
        Intent intent = new Intent(this, mapSeenUsers.class);
        startActivity(intent);
    }

    //funci'on que guarda la ruta en el archivo Rutas.obj
    private void guardarRuta(Ruta ruta) {

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("Rutas");
        myRef.child(ruta.getId()).setValue(ruta);

    }

    //funcion para mostrar los paraderos y hacer el popup para seleccionarlo
    private void getParaderos(Ruta ruta, Usuario persona){
        for(int i=0; i<ruta.getLatParaderos().size();i++){
            listaParaderos.add(getAddress(new LatLng(ruta.getLatParaderos().get(i),ruta.getLngParaderos().get(i))));
        }
        listParaderos.setAdapter(new ArrayAdapter<String>(checkRuta.this, android.R.layout.simple_list_item_1,listaParaderos));
        listParaderos.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                AlertDialog.Builder confirmParadero = new AlertDialog.Builder(checkRuta.this);
                confirmParadero.setTitle("Confirmar Paradero");
                confirmParadero.setMessage("Desea confirmar su paradero en: "+listaParaderos.get(position));
                confirmParadero.setPositiveButton("Confirmar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if(persona.getCelular() == ruta.getUsuario()){
                            Toast.makeText(checkRuta.this,"¡Usted es el conductor de esta ruta!",Toast.LENGTH_SHORT);
                        }
                        else{
                            guardarPasajero(ruta, persona);
                        }


                    }
                });
                confirmParadero.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(checkRuta.this,"Por favor seleccionar un paradero", Toast.LENGTH_SHORT).show();
                    }
                });
                confirmParadero.show();
            }
        });

    }
    //funcion para guardar el pasajero en la ruta
    private void guardarPasajero(Ruta ruta, Usuario persona){
        listaPasajeros = new ArrayList<Usuario>();
        listaPasajeros = ruta.getPasajeros();
        boolean exist=false;
        try{
            for(int i=0; i<listaPasajeros.size();i++){
                if(listaPasajeros.get(i)==persona.getCelular()){
                    exist=true;
                }
                else{
                    exist=false;
                }
            }
        }
        catch (NullPointerException e){
            exist=false;
        }
        if(exist==true){
            Toast.makeText(checkRuta.this,"Pasajero ya inscrito en la ruta, recuerde validar",Toast.LENGTH_SHORT);
        }
        else{
            try {
                listaPasajeros.add(persona.getCelular());
            }
            catch (NullPointerException e){
                listaPasajeros = new ArrayList<Usuario>();
                listaPasajeros.add(persona.getCelular());

            }
            lPasajeros.add(persona.getCelular());
            ruta.setPasajeros(listaPasajeros);
            Toast.makeText(checkRuta.this,"Pasajero inscrito en la ruta, recuerde validar", Toast.LENGTH_SHORT);
        }
    }

    //funcion para ver el perfil de cada pasajero
    private void getPasajeros(){
        listPasajeros.setAdapter(new ArrayAdapter<String>(checkRuta.this, android.R.layout.simple_list_item_1,lPasajeros));
        listPasajeros.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                //ver el perfil de la persona
            }
        });


    }

    private String getAddress(LatLng place){
        Geocoder geocoder;
        List<Address> addresses;
        String address = null;
        geocoder = new Geocoder(this, Locale.getDefault());
        try {
            addresses = geocoder.getFromLocation(place.latitude, place.longitude, 1);
            address = addresses.get(0).getAddressLine(0);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return address;
    }

    private void cargarArchivo(){

        FirebaseDatabase.getInstance().getReference().child("Rutas").orderByChild("id").equalTo(Id).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(snapshot.exists()) {
                    Ruta rutaTmp;
                    List<Double> latParaderos;
                    List<Double> lngParaderos;
                    List<Double> latLineaRuta;
                    List<Double> lngLineaRuta;
                    List<String> pasajeros;
                    HashMap output = (HashMap) snapshot.getValue();
                    HashMap output2 = (HashMap) output.get(Id);
                    System.out.println(output2);
                    String id = (String) output2.get("id");
                    String usuario = (String) output2.get("usuario");
                    String fecha = (String) output2.get("fecha");
                    String hora = (String) output2.get("hora");
                    double latOrigin = (double) Double.valueOf(output2.get("latOrigen").toString());
                    double lngOrigin = (double) Double.valueOf(output2.get("lngOrigen").toString());
                    double latDestino = (double) Double.valueOf(output2.get("latDestino").toString());
                    double lngDestino = (double) Double.valueOf(output2.get("lngDestino").toString());
                    try {
                        latParaderos = (List<Double>) makeSplit(output.get("latParaderos").toString());
                        lngParaderos = (List<Double>) makeSplit(output.get("lngParaderos").toString());
                    }
                    catch (NullPointerException e){
                        latParaderos = new ArrayList<>();
                        lngParaderos = new ArrayList<>();
                    }
                    String placa = (String) output2.get("placa");

                    try {
                        latLineaRuta = (List<Double>) makeSplit(output.get("latLineaRuta").toString());
                        lngLineaRuta = (List<Double>) makeSplit(output2.get("lngLineaRuta").toString());

                    }
                    catch (NullPointerException e){
                        latLineaRuta = new ArrayList<>();
                        lngLineaRuta = new ArrayList<>();
                    }

                    try {
                        pasajeros = (List<String>) makeSplit2(output2.get("pasajeros").toString());
                    }
                    catch (NullPointerException e){
                        pasajeros = new ArrayList<>();
                    }

                    rutaTmp = new Ruta(id, usuario, fecha, hora, latOrigin, lngOrigin, latDestino, lngDestino, latParaderos, lngParaderos, placa, latLineaRuta, lngLineaRuta, pasajeros);
                    ruta = rutaTmp;
                }
                else{
                    System.out.println("error");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Ruta rutaTmp=new Ruta(null,null);
                ruta=rutaTmp;
                System.out.println(error);
                Toast.makeText(checkRuta.this,"Id no valido",Toast.LENGTH_SHORT);

            }
        });


    }
    private List<String> makeSplit2(String stringArray){
        String sub = stringArray.substring(1,stringArray.length()-1);
        String[] parts= sub.split(",");
        List<String> ret = new ArrayList<>();
        for (int i =0; i<parts.length;i++){
            ret.add(parts[i]);
        }
        return ret;

    }

    private List<Double> makeSplit(String stringArray){
        String sub = stringArray.substring(1,stringArray.length()-1);
        String[] parts= sub.split(",");
        List<Double> ret = new ArrayList<>();
        for (int i =0; i<parts.length;i++){
            ret.add(Double.valueOf(parts[i]));
        }
        return ret;

    }

    private void getConductor(String idConductor){
        DatabaseReference ref = (DatabaseReference) FirebaseDatabase.getInstance().getReference("Conductores").orderByChild("celular").equalTo(idConductor);
        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(snapshot.exists()) {
                    HashMap output = (HashMap) snapshot.getValue();
                    HashMap output2 = (HashMap) output.get(idConductor);
                    String nombre = (String) output2.get("nombre");
                    String apellido = (String) output2.get("apellido");
                    String correo = (String) output2.get("correo");
                    String celular = (String) output2.get("celular");
                    Usuario conductorTmp = new Usuario(nombre, apellido, celular, correo);
                    conductor = conductorTmp;
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Usuario conductorTmp = new Usuario(null, null, null, null);
                conductor = conductorTmp;
                Toast.makeText(checkRuta.this,"El conductor no existe",Toast.LENGTH_SHORT);
            }
        });

    }

}