package com.example.map;

import com.google.android.gms.maps.model.LatLng;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Ruta implements Serializable {

    private static final long serializableUID = 1597258310032161934L;

    private String id;
    private String usuario;
    private String fecha;
    private String hora;
    private double latOrigen;
    private double lngOrigen;
    private double latDestino;
    private double lngDestino;
    private List<Double> latParaderos;
    private List<Double> lngParaderos;
    private String placa;
    //private LatLng origen;
    //private LatLng destino;
    //private ArrayList<LatLng> paraderos;
    private List<Double> latLineaRuta;
    private List<Double> lngLineaRuta;
    private List<String> pasajeros;

    public Ruta(String usuario, String placa){
        setUsuario(usuario);
        setPlaca(placa);
        setLatDestino(0);
        setLngDestino(0);
        setLatOrigen(0);
        setLngOrigen(0);
        setLatParaderos(null);
        setLngParaderos(null);
        setFecha(null);
        setHora(null);
        //setDestino(null);
        //setOrigen(null);
        setLatLineaRuta(null);
        setLngLineaRuta(null);
        setPasajeros(null);
        setId(null);

        //setParaderos(null);
    }

    public Ruta(String id, String usuario, String fecha, String hora, double latOrigen, double lngOrigen, double latDestino,double lngDestino,List<Double> latParaderos, List<Double> lngParaderos,String placa, List<Double> latLineaRuta, List<Double> lngLineaRuta,List<String> pasajeros){
        setId(id);
        setUsuario(usuario);
        setFecha(fecha);
        setHora(hora);
        setLatOrigen(latOrigen);
        setLngOrigen(lngOrigen);
        setLatDestino(latDestino);
        setLngDestino(lngDestino);
        setLatParaderos(latParaderos);
        setLngParaderos(lngParaderos);
        setPlaca(placa);
        setLatLineaRuta(latLineaRuta);
        setLngLineaRuta(lngLineaRuta);
        setPasajeros(pasajeros);
    }

    public void setPlaca(String placa){this.placa = placa;}

    public String getPlaca(){return this.placa;}

    public void setPasajeros(List<String> pasajeros){this.pasajeros=pasajeros;}

    public List<String> getPasajeros(){return this.pasajeros;}

    public void setFecha(String fecha){
        this.fecha = fecha;
    }

    public String getFecha(){
        return this.fecha;
    }

    public void setHora(String hora){
        this.hora = hora;
    }

    public String getHora(){
        return this.hora;
    }

    public void setId(String id){
        this.id = id;
    }

    public String getId(){
        return this.id;
    }

    //public void setOrigen(LatLng origen){
        //this.origen = origen;
    //}
    //public LatLng getOrigen(){
        //return this.origen;
    //}

    //public void setDestino(LatLng destino){
        //this.destino = destino;
    //}
    //public LatLng getDestino(){
        //return this.destino;
    //}

    public void setUsuario(String usuario){
        this.usuario = usuario;
    }
    public String getUsuario(){
        return this.usuario;
    }
    public void setLatOrigen(double latOrigen){
        this.latOrigen = latOrigen;
    }
    public double getLatOrigen(){
        return this.latOrigen;
    }

    public void setLngOrigen(double lngOrigen){
        this.lngOrigen = lngOrigen;
    }
    public double getLngOrigen(){
        return this.lngOrigen;
    }

    public void setLatDestino(double latDestino){
        this.latDestino = latDestino;
    }
    public double getLatDestino(){
        return this.latDestino;
    }

    public void setLngDestino(double lngDestino){
        this.lngDestino = lngDestino;
    }
    public double getLngDestino(){
        return this.lngDestino;
    }

    public void setLatParaderos(List<Double> latParaderos){
        this.latParaderos = latParaderos;
    }

    public List<Double> getLatParaderos(){
        return this.latParaderos;
    }

    public void setLngParaderos(List<Double> lngParaderos){
        this.lngParaderos = lngParaderos;
    }

    public List<Double> getLngParaderos(){
        return this.lngParaderos;
    }
    //public void setParaderos(ArrayList<LatLng> paraderos){
        //this.paraderos = paraderos;
    //}
    //public ArrayList<LatLng> getParaderos(){
        //return this.paraderos;
    //}

    public void setLatLineaRuta(List<Double> latLineaRuta){
        this.latLineaRuta = latLineaRuta;
    }
    public List<Double> getLatLineaRuta(){
        return this.latLineaRuta;
    }

    public void setLngLineaRuta(List<Double> lngLineaRuta){
        this.lngLineaRuta = lngLineaRuta;
    }
    public List<Double> getLngLineaRuta(){
        return this.lngLineaRuta;
    }
}
