package com.example.map;

import java.io.Serializable;
import java.util.ArrayList;

public class Usuario implements Serializable {
    private String nombre;
    private String apellido;
    private String correo;
    private String celular;


    public Usuario(String nombre, String apellido, String celular,String correo){
        setNombre(nombre);
        setApellido(apellido);
        setCorreo(correo);
        setCelular(celular);
    }

    public void setNombre(String nombre){
        this.nombre = nombre;
    }

    public String getNombre(){
        return this.nombre;
    }

    public void setApellido(String apellido){
        this.apellido = apellido;
    }

    public String getApellido(){
        return this.apellido;
    }

    public void setCelular(String celular){this.celular = celular;}

    public String getCelular(){return this.celular;}

    public void setCorreo(String correo){
        this.correo = correo;
    }

    public String getCorreo(){
        return this.correo;
    }

}
