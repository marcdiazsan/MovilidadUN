package com.example.map;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Collection;
import java.util.Iterator;
import java.util.ListIterator;
import java.util.Random;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.example.map.R;
import com.example.map.TaskLoadedCallback;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;

import com.example.map.FetchURL;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.maps.android.ui.IconGenerator;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.logging.Level;
import java.util.logging.Logger;

public class MainActivity extends AppCompatActivity implements OnMapReadyCallback, TaskLoadedCallback {

    GoogleMap map;

    Button btnCalcularRuta;
    Button btnAdicionarParaderos;
    Button btnGuardarRuta;
    ImageButton btnFecha;
    ImageButton btnHora;

    private DatePickerDialog.OnDateSetListener nDateSetListener;
    private TimePickerDialog.OnTimeSetListener onTimeSetListener;

    private static final String TAG = "MainActivity";

    private MarkerOptions origin, end;
    private Polyline currentPolyline;
    private ArrayList<LatLng> markerPoints;
    private ArrayList<LatLng> paraderos;
    private ArrayList<String> direcciones;
    private IconGenerator icgOrigin;
    private IconGenerator icgEnd;
    private IconGenerator paradero;
    private boolean putParaderos;
    private Ruta ruta ;
    private List<LatLng> puntosPolyLine;

    private FusedLocationProviderClient client;
    MapFragment mapFragment;

    //usuario conductor de la ruta que se va a a hacer
    private Usuario usuario1= new Usuario("pepito","perez","+573896739089","pepitoperez@gmail.com");

    FileOutputStream file = null;
    FileInputStream inputFile = null;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
        SimpleDateFormat df2 = new SimpleDateFormat("H:m", Locale.getDefault());

        String formattedDate = df.format(calendar.getTime());
        String otherTime = df2.format(calendar.getTime());

        client = LocationServices.getFusedLocationProviderClient(this);

        if (ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED){
            getCurrentLocation();
        }
        else {
            ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION},44);
        }
        //se crea la ruta con el conductor
        ruta = new Ruta(usuario1.getCelular(),"abc123");

        //guarda hora y fecha actuales por default
        ruta.setFecha(formattedDate);
        ruta.setHora(otherTime);

        btnCalcularRuta = findViewById(R.id.calcularRuta);
        btnAdicionarParaderos = findViewById(R.id.adicionarParaderos);
        btnGuardarRuta = findViewById(R.id.guardarRuta);

        btnFecha = findViewById(R.id.seleccionarFecha);
        btnHora = findViewById(R.id.seleccionarHora);

        markerPoints = new ArrayList<LatLng>();
        paraderos = new ArrayList<LatLng>();

        putParaderos = false;

        mapFragment = (MapFragment) getFragmentManager().findFragmentById(R.id.mapFrag);

        //listener para adicionar los paraderos
        btnAdicionarParaderos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                putParaderos=true;
                System.out.println(putParaderos);
            }
        });

        //boton para calcular la ruta con la API de google maps una vez que se tienen minimo origen y destino
        btnCalcularRuta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new FetchURL(MainActivity.this).execute(getUrl(origin.getPosition(), end.getPosition(), "driving", paraderos), "driving");
            }
        });

        //boton para guardar la ruta a un archivo de tipo .obj dentro del telefono (si tuvieramos platas eria a un servidor externo, pero aja)
        btnGuardarRuta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //guardarRuta(ruta);

                //esta funcion change act es la que cambia de actividad o de ventana una vez se guarde la ruta
                changeAct();

            }
        });



        //boton para hacer el cambio de la fecha a la de salida
        btnFecha.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar cal = Calendar.getInstance();
                int year = cal.get(Calendar.YEAR);
                int month = cal.get(Calendar.MONTH);
                int day = cal.get(Calendar.DAY_OF_MONTH);
                DatePickerDialog dateDialog = new DatePickerDialog(MainActivity.this,android.R.style.Theme_Holo_Light_Dialog_MinWidth,nDateSetListener,year,month,day);
                dateDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                dateDialog.show();
            }
        });
        nDateSetListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                month = month + 1;
                Log.d(TAG, "onDateSet : dd/mm/yyyy: "+ year+ "/"+month+"/"+dayOfMonth );
                String date = dayOfMonth+"/"+month+"/"+year;
                ruta.setFecha(date);
            }
        };
        //boton para hacer el cambio de la hora de salida
        btnHora.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar calHour = Calendar.getInstance();
                int mHour = calHour.get(Calendar.HOUR_OF_DAY);
                int mMin = calHour.get(Calendar.MINUTE);
                TimePickerDialog timeDialog = new TimePickerDialog(MainActivity.this,android.R.style.Theme_Holo_Light_Dialog_MinWidth,onTimeSetListener,mHour,mMin,true);
                timeDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                timeDialog.show();
            }
        });
        onTimeSetListener = new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                Log.d(TAG,"onTimeSet : "+ hourOfDay+":"+minute);
                String time= hourOfDay+":"+minute;
                ruta.setHora(time);
            }
        };


        getCurrentLocation();
        mapFragment.getMapAsync(this);
    }

    //cambio de ventana, en ese caso lo hace a check ruta
    public void changeAct() {
        Intent intent = new Intent(this, checkRuta.class);
        startActivity(intent);
    }

    private void guardarRuta(Ruta ruta) {

        getId(ruta);
        ruta.setLatOrigen(origin.getPosition().latitude);
        ruta.setLngOrigen(origin.getPosition().longitude);
        ruta.setLatDestino(end.getPosition().latitude);
        ruta.setLngDestino(end.getPosition().longitude);

        List<Double> latParaderos = new ArrayList<Double>();
        List<Double> lngParaderos = new ArrayList<Double>();

        for (int i =0; i<paraderos.size();i++){
            latParaderos.add(paraderos.get(i).latitude);
            lngParaderos.add(paraderos.get(i).longitude);
        }
        ruta.setLatParaderos(latParaderos);
        ruta.setLngParaderos(lngParaderos);
        List<Double> latLineaRuta = new ArrayList<Double>();
        List<Double> lngLineaRuta = new ArrayList<Double>();

        for (int i =0; i<puntosPolyLine.size();i++){
            latLineaRuta.add(puntosPolyLine.get(i).latitude);
            lngLineaRuta.add(puntosPolyLine.get(i).longitude);
        }
        ruta.setLatLineaRuta(latLineaRuta);
        ruta.setLngLineaRuta(lngLineaRuta);

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("Rutas");
        myRef.child(ruta.getId()).setValue(ruta, new DatabaseReference.CompletionListener() {
            @Override
            public void onComplete(@Nullable DatabaseError error, @NonNull DatabaseReference ref) {
                System.err.println(error);
            }
        });

    }

    //funcion que retorna todas las rutas guardadas en el archivo previamente, o un array vacio si no hay nada

    //crea un id para la ruta
    private void getId(Ruta ruta){
        Random rand = new Random();
        int num = rand.nextInt(9999-1000)+1000;
        ruta.setId(Integer.toString(num));
    }

    //funcion que obtiene las direcciones de los paraderos y lugar de origen y fin
    private ArrayList<String> getAddress(ArrayList<LatLng> places){
        Geocoder geocoder;
        List<Address> addresses;
        ArrayList<String> direccionesParaderos = null;
        geocoder = new Geocoder(this, Locale.getDefault());
        for (int i=0; i<places.size();i++ ) {
            try {
                addresses = geocoder.getFromLocation(places.get(i).latitude, places.get(i).longitude, 1);
                String address = addresses.get(0).getAddressLine(0);
                direccionesParaderos.add(address);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return direccionesParaderos;
    }

    //funcion que obtiene la localizacion actual y le hace zoom
    private void getCurrentLocation(){
        @SuppressLint("MissingPermission") Task<Location> task = client.getLastLocation();
        task.addOnSuccessListener(new OnSuccessListener<Location>() {
            @Override
            public void onSuccess(Location location) {
                if (location != null){
                    mapFragment.getMapAsync(new OnMapReadyCallback() {
                        @Override
                        public void onMapReady(GoogleMap googleMap) {
                            LatLng latLng = new LatLng(location.getLatitude(),location.getLongitude());
                            MarkerOptions options = new MarkerOptions().position(latLng).title("Posicion Actual");
                            googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng,16));
                            googleMap.addMarker(options);
                        }
                    });
                }
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if(requestCode == 44){
            if(grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
                getCurrentLocation();
            }
        }
    }

    //funcion que revisa donde se hace click en el mapa para poner los paraderos y los puntos de inicio y fin
    @Override
    public void onMapReady(GoogleMap googleMap) {
        map = googleMap;
        icgOrigin= new IconGenerator(this);
        icgEnd = new IconGenerator(this);
        paradero = new IconGenerator(this);

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        map.setMyLocationEnabled(true);


        map.setOnMapClickListener(new GoogleMap.OnMapClickListener() {

            @Override
            public void onMapClick(LatLng point) {
                if(!putParaderos) {

                    if (markerPoints.size() > 1) {
                        markerPoints.clear();
                        map.clear();
                    }

                    markerPoints.add(point);

                    MarkerOptions options = new MarkerOptions();

                    // Setting the position of the marker
                    options.position(point);

                    if (markerPoints.size() == 1) {

                        icgOrigin.setStyle(IconGenerator.STYLE_GREEN);
                        options.title("Origen");
                        //options.icon(BitmapDescriptorFactory.
                        //defaultMarker(BitmapDescriptorFactory.HUE_GREEN));
                        origin = options;
                        Log.d("mylog", "Added Marker Origin");
                        //map.addMarker(place1);
                        addIcon(map, icgOrigin, "Origin", point);

                    } else if (markerPoints.size() == 2) {
                        icgEnd.setStyle(IconGenerator.STYLE_RED);
                        options.title("Destino");
                        //options.icon(BitmapDescriptorFactory
                        //.defaultMarker(BitmapDescriptorFactory.HUE_RED));
                        end = options;
                        //map.addMarker(end);
                        Log.d("mylog", "Added Marker Destin");
                        addIcon(map, icgEnd, "Destino", point);
                    }
                }
                else{
                    icgEnd.setStyle(IconGenerator.STYLE_ORANGE);
                    paraderos.add(point);
                    Log.d("mylog", "Added Paradero");
                    addIcon(map,paradero,"Paradero",point);

                }

            }
        });

    }

    private void addIcon(GoogleMap googleMap, IconGenerator iconFactory, CharSequence text, LatLng position) {
        MarkerOptions markerOptions = new MarkerOptions().
                icon(BitmapDescriptorFactory.fromBitmap(iconFactory.makeIcon(text))).
                position(position).
                anchor(iconFactory.getAnchorU(), iconFactory.getAnchorV());
        googleMap.addMarker(markerOptions);
    }

    //obtener url para hacer el rquest a la API de google maps
    private String getUrl(LatLng origin, LatLng dest, String directionMode, ArrayList<LatLng> paraderos) {
        // Origin of route
        String str_origin = "origin=" + origin.latitude + "," + origin.longitude;
        // Destination of route
        String str_dest = "destination=" + dest.latitude + "," + dest.longitude;
        // Mode
        String mode = "mode=" + directionMode;
        String waypoints = "waypoints=";
        if (paraderos.size()>=1){
            for(int i=0; i<paraderos.size(); i++){
                if (i == paraderos.size() - 1) {
                    waypoints += paraderos.get(i).latitude+"%2C"+paraderos.get(i).longitude;
                }
                else{
                    waypoints += paraderos.get(i).latitude+"%2C"+paraderos.get(i).longitude+"|";
                }
            }
        }
        String parameters;
        // Building the parameters to the web service
        if(paraderos.size()==0){
            parameters = str_origin + "&" + str_dest + "&" + mode;
        }
        else {
            parameters = str_origin + "&" + str_dest + "&" + mode + "&" +waypoints;
        }

        // Output format
        String output = "json";
        // Building the url to the web service
        String url = "https://maps.googleapis.com/maps/api/directions/" + output + "?" + parameters + "&key=" + "AIzaSyAw6WAnRKF0i85H2OIZdtfLiI1cszfRLwc";
        return url;
    }

    //adiciona la polylinea de la ruta en el mapa
    @Override
    public void onTaskDone(Object... values) {
        if (currentPolyline != null)
            currentPolyline.remove();
        currentPolyline = map.addPolyline((PolylineOptions) values[0]);
        puntosPolyLine = currentPolyline.getPoints();
    }
}