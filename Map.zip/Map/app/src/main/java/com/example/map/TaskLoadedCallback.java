package com.example.map;

public interface TaskLoadedCallback {
    void onTaskDone(Object... values);
}